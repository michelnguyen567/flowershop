-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2019 at 04:07 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flower`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_customer` int(11) DEFAULT NULL,
  `date_order` date DEFAULT NULL,
  `total` float DEFAULT NULL COMMENT 'tổng tiền',
  `payment` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'hình thức thanh toán',
  `note` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `id_customer`, `date_order`, `total`, `payment`, `note`, `created_at`, `updated_at`) VALUES
(14, 14, '2017-03-23', 160000, 'COD', 'k', '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(13, 13, '2017-03-21', 400000, 'ATM', 'Vui lòng giao hàng trước 5h', '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(12, 12, '2017-03-21', 520000, 'COD', 'Vui lòng chuyển đúng hạn', '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(11, 11, '2017-03-21', 420000, 'COD', 'không chú', '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(15, 15, '2017-03-24', 220000, 'COD', 'e', '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(16, 17, '2019-03-24', 150000, 'ATM', 'e', '2019-03-23 20:20:42', '2019-03-23 20:20:42'),
(17, 18, '2019-03-24', 150000, 'ATM', 'e', '2019-03-23 20:21:35', '2019-03-23 20:21:35'),
(18, 19, '2019-03-24', 150000, 'ATM', 'e', '2019-03-23 20:25:46', '2019-03-23 20:25:46'),
(19, 20, '2019-03-24', 150000, 'COD', 'asvas', '2019-03-23 20:30:40', '2019-03-23 20:30:40'),
(20, 21, '2019-03-25', 180000, 'ATM', 'a', '2019-03-24 21:59:51', '2019-03-24 21:59:51'),
(21, 22, '2019-03-25', 150000, 'ATM', 'a', '2019-03-24 22:08:43', '2019-03-24 22:08:43'),
(22, 23, '2019-03-25', 180000, 'ATM', 'a', '2019-03-25 00:09:33', '2019-03-25 00:09:33'),
(23, 24, '2019-03-25', 150000, 'ATM', 'a', '2019-03-25 00:23:41', '2019-03-25 00:23:41'),
(24, 25, '2019-03-25', 180000, 'ATM', 'a', '2019-03-25 00:32:09', '2019-03-25 00:32:09'),
(25, 30, '2019-03-25', 150000, 'ATM', 'a', '2019-03-25 00:35:04', '2019-03-25 00:35:04'),
(26, 31, '2019-03-25', 180000, 'ATM', 'day la ghi chu', '2019-03-25 00:35:47', '2019-03-25 00:35:47'),
(27, 32, '2019-03-25', 840000, 'ATM', 'dgji asa', '2019-03-25 00:42:34', '2019-03-25 00:42:34'),
(28, 33, '2019-03-25', 610000, 'ATM', 'a', '2019-03-25 09:27:16', '2019-03-25 09:27:16'),
(29, 36, '2019-03-25', 360000, 'ATM', 'a', '2019-03-25 09:30:17', '2019-03-25 09:30:17'),
(30, 38, '2019-03-25', 180000, 'COD', 'a', '2019-03-25 09:31:53', '2019-03-25 09:31:53'),
(31, 40, '2019-03-25', 150000, 'ATM', 'a', '2019-03-25 09:41:18', '2019-03-25 09:41:18'),
(32, 41, '2019-03-25', 150000, 'ATM', 'a', '2019-03-25 09:51:17', '2019-03-25 09:51:17'),
(33, 42, '2019-03-25', 180000, 'COD', 'a', '2019-03-25 09:57:35', '2019-03-25 09:57:35'),
(34, 44, '2019-03-25', 150000, 'COD', 'a', '2019-03-25 10:03:51', '2019-03-25 10:03:51'),
(35, 45, '2019-03-25', 150000, 'COD', 'a', '2019-03-25 10:05:40', '2019-03-25 10:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `bill_detail`
--

CREATE TABLE `bill_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bill` int(10) NOT NULL,
  `id_product` int(10) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'số lượng',
  `unit_price` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_detail`
--

INSERT INTO `bill_detail` (`id`, `id_bill`, `id_product`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES
(18, 15, 62, 5, 220000, '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(17, 14, 2, 1, 160000, '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(16, 13, 60, 1, 200000, '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(15, 13, 59, 1, 200000, '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(14, 12, 60, 2, 200000, '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(13, 12, 61, 1, 120000, '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(12, 11, 61, 1, 120000, '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(11, 11, 57, 2, 150000, '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(19, 18, 3, 1, 150000, '2019-03-23 20:25:46', '2019-03-23 20:25:46'),
(20, 19, 3, 1, 150000, '2019-03-23 20:30:40', '2019-03-23 20:30:40'),
(21, 20, 2, 1, 180000, '2019-03-24 21:59:51', '2019-03-24 21:59:51'),
(22, 21, 1, 1, 150000, '2019-03-24 22:08:43', '2019-03-24 22:08:43'),
(23, 22, 2, 1, 180000, '2019-03-25 00:09:33', '2019-03-25 00:09:33'),
(24, 23, 1, 1, 150000, '2019-03-25 00:23:41', '2019-03-25 00:23:41'),
(25, 24, 2, 1, 180000, '2019-03-25 00:32:09', '2019-03-25 00:32:09'),
(26, 25, 1, 1, 150000, '2019-03-25 00:35:04', '2019-03-25 00:35:04'),
(27, 26, 2, 1, 180000, '2019-03-25 00:35:47', '2019-03-25 00:35:47'),
(28, 27, 2, 2, 180000, '2019-03-25 00:42:34', '2019-03-25 00:42:34'),
(29, 27, 4, 1, 160000, '2019-03-25 00:42:34', '2019-03-25 00:42:34'),
(30, 27, 7, 2, 160000, '2019-03-25 00:42:34', '2019-03-25 00:42:34'),
(31, 28, 1, 2, 150000, '2019-03-25 09:27:16', '2019-03-25 09:27:16'),
(32, 28, 5, 1, 160000, '2019-03-25 09:27:16', '2019-03-25 09:27:16'),
(33, 28, 3, 1, 150000, '2019-03-25 09:27:16', '2019-03-25 09:27:16'),
(34, 29, 2, 2, 180000, '2019-03-25 09:30:17', '2019-03-25 09:30:17'),
(35, 30, 2, 1, 180000, '2019-03-25 09:31:53', '2019-03-25 09:31:53'),
(36, 31, 1, 1, 150000, '2019-03-25 09:41:18', '2019-03-25 09:41:18'),
(37, 32, 1, 1, 150000, '2019-03-25 09:51:17', '2019-03-25 09:51:17'),
(38, 33, 2, 1, 180000, '2019-03-25 09:57:35', '2019-03-25 09:57:35'),
(39, 34, 1, 1, 150000, '2019-03-25 10:03:51', '2019-03-25 10:03:51'),
(40, 35, 1, 1, 150000, '2019-03-25 10:05:40', '2019-03-25 10:05:40');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `ho` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `ho`, `name`, `address`, `phone_number`, `note`, `created_at`, `updated_at`) VALUES
(15, 'a', 'ê', 'e', 'e', 'e', '2019-03-24 02:56:59', '2017-03-24 07:14:32'),
(14, 'a', 'hhh', 'Lê thị riêng', '99999999999999999', 'k', '2019-03-24 02:57:02', '2017-03-23 04:46:05'),
(13, 'a', 'Hương Hương', 'Lê Thị Riêng, Quận 1', '23456789', 'Vui lòng giao hàng trước 5h', '2019-03-24 02:57:03', '2017-03-21 07:29:31'),
(12, 'a', 'Khoa phạm', 'Lê thị riêng', '1234567890', 'Vui lòng chuyển đúng hạn', '2019-03-24 02:57:04', '2017-03-21 07:20:07'),
(11, 'a', 'Hương Hương', 'Lê Thị Riêng, Quận 1', '234567890-', 'không chú', '2019-03-24 02:57:05', '2017-03-21 07:16:09'),
(16, 'a', 'b', 'd', '0', 'e', '2019-03-23 20:20:14', '2019-03-23 20:20:14'),
(17, 'a', 'b', 'd', '0', 'e', '2019-03-23 20:20:42', '2019-03-23 20:20:42'),
(18, 'a', 'b', 'd', '0', 'e', '2019-03-23 20:21:35', '2019-03-23 20:21:35'),
(19, 'a', 'b', 'd', '0', 'e', '2019-03-23 20:25:46', '2019-03-23 20:25:46'),
(20, 'le', 'bao', 'asd', '009', 'asvas', '2019-03-23 20:30:40', '2019-03-23 20:30:40'),
(21, 'a', 'a', 'a', '1', 'a', '2019-03-24 21:59:51', '2019-03-24 21:59:51'),
(22, 'a', 'a', 'a', '1', 'a', '2019-03-24 22:08:43', '2019-03-24 22:08:43'),
(23, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:09:33', '2019-03-25 00:09:33'),
(24, 'a', 'a', 'a', '0', 'a', '2019-03-25 00:23:41', '2019-03-25 00:23:41'),
(25, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:32:09', '2019-03-25 00:32:09'),
(26, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:33:47', '2019-03-25 00:33:47'),
(27, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:33:59', '2019-03-25 00:33:59'),
(28, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:34:19', '2019-03-25 00:34:19'),
(29, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:34:27', '2019-03-25 00:34:27'),
(30, 'a', 'a', 'a', '1', 'a', '2019-03-25 00:35:04', '2019-03-25 00:35:04'),
(31, 'a', 'a', 'a', '1', 'day la ghi chu', '2019-03-25 00:35:47', '2019-03-25 00:35:47'),
(32, 'a', 'a', 'a', '1', 'dgji asa', '2019-03-25 00:42:34', '2019-03-25 00:42:34'),
(33, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:27:16', '2019-03-25 09:27:16'),
(34, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:29:03', '2019-03-25 09:29:03'),
(35, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:29:22', '2019-03-25 09:29:22'),
(36, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:30:17', '2019-03-25 09:30:17'),
(37, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:31:08', '2019-03-25 09:31:08'),
(38, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:31:53', '2019-03-25 09:31:53'),
(39, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:40:45', '2019-03-25 09:40:45'),
(40, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:41:18', '2019-03-25 09:41:18'),
(41, 'a', 'a', 'a', '1', 'a', '2019-03-25 09:51:17', '2019-03-25 09:51:17'),
(42, 'a', 'a', 'a', '0', 'a', '2019-03-25 09:57:35', '2019-03-25 09:57:35'),
(43, 'a', 'a', 'a', '0', 'a', '2019-03-25 10:01:35', '2019-03-25 10:01:35'),
(44, 'a', 'a', 'a', '1', 'a', '2019-03-25 10:03:51', '2019-03-25 10:03:51'),
(45, 'a', 'a', 'a', '1', 'a', '2019-03-25 10:05:40', '2019-03-25 10:05:40'),
(46, 'a', 'a', 'a', '1', 'a', '2019-03-25 10:07:14', '2019-03-25 10:07:14');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'tiêu đề',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'nội dung',
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'hình',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `image`, `create_at`, `update_at`) VALUES
(1, 'Mùa trung thu năm nay, Hỷ Lâm Môn muốn gửi đến quý khách hàng sản phẩm mới xuất hiện lần đầu tiên tại Việt nam \"Bánh trung thu Bơ Sữa HongKong\".', 'Những ý tưởng dưới đây sẽ giúp bạn sắp xếp tủ quần áo trong phòng ngủ chật hẹp của mình một cách dễ dàng và hiệu quả nhất. ', 'sample1.jpg', '2017-03-11 06:20:23', '0000-00-00 00:00:00'),
(2, 'Tư vấn cải tạo phòng ngủ nhỏ sao cho thoải mái và thoáng mát', 'Chúng tôi sẽ tư vấn cải tạo và bố trí nội thất để giúp phòng ngủ của chàng trai độc thân thật thoải mái, thoáng mát và sáng sủa nhất. ', 'sample2.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(3, 'Đồ gỗ nội thất và nhu cầu, xu hướng sử dụng của người dùng', 'Đồ gỗ nội thất ngày càng được sử dụng phổ biến nhờ vào hiệu quả mà nó mang lại cho không gian kiến trúc. Xu thế của các gia đình hiện nay là muốn đem thiên nhiên vào nhà ', 'sample3.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(4, 'Hướng dẫn sử dụng bảo quản đồ gỗ, nội thất.', 'Ngày nay, xu hướng chọn vật dụng làm bằng gỗ để trang trí, sử dụng trong văn phòng, gia đình được nhiều người ưa chuộng và quan tâm. Trên thị trường có nhiều sản phẩm mẫu ', 'sample4.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00'),
(5, 'Phong cách mới trong sử dụng đồ gỗ nội thất gia đình', 'Đồ gỗ nội thất gia đình ngày càng được sử dụng phổ biến nhờ vào hiệu quả mà nó mang lại cho không gian kiến trúc. Phong cách sử dụng đồ gỗ hiện nay của các gia đình hầu h ', 'sample5.jpg', '2016-10-20 02:07:14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_type` int(10) UNSIGNED DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `unit_price` float DEFAULT NULL,
  `promotion_price` float DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new` tinyint(4) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `id_type`, `description`, `unit_price`, `promotion_price`, `image`, `unit`, `new`, `created_at`, `updated_at`) VALUES
(1, 'Hoa sen hồng', 6, 'Hoa sen hồng được phổ biến ở nhiều quốc gIa Châu Á trong đó có Việt Nam, sen hồng cũng là loại sen được xuất hiện nhiều trong các truyền thuyết về phật giáo', 150000, 120000, 'hoasenhong.jpg', 'Bó', 1, '2016-10-26 03:00:16', '2016-10-24 22:11:00'),
(2, 'Hoa sen Cung Đình', 6, 'Hoa sen Cung Đình là một giống hoa sen mới hiện nay có tên gọi là Nelumbo nucifera. Là một cây sen nhỏ đẹp các cánh của hoa sen xếp chồng lên nhau theo trình tự nhất định  và có hương thơm ngào ngạt, lan tỏa khắp nơi.', 180000, 160000, 'hoasencungdinh.jpg', 'Bó', 0, '2016-10-26 03:00:16', '2016-10-24 22:11:00'),
(3, 'Hoa hướng dương', 7, 'Hoa hướng dương là loài hoa biểu tượng của mặt trời của hi vọng, của sự ấm áp. Loài hoa luôn hướng về mặt trời, hướng về tương lai, hướng về những điều tốt đẹp nhất. Hiện nay có khá nhiều người yêu thích loại hoa xinh đẹp này, trồng trong nhà như một cây trang trí tô điểm không gian. Những bông hoa nở to màu vàng chói lóa đã làm cho ngôi nhà thêm bừng sáng. Hoa hướng dương bây giờ không chỉ nở vào mùa hè mà người ta đã biết cách trồng làm sao cho hoa nở được cả vào mùa đông lạnh giá nữa, hoa như mang thêm sự ấm áp sưởi ấm những ngày đông. Tên tiếng Anh: Pelargonium hortorum Balley Tên khoa học: Helianthus annus Họ: Cúc Nguồn gốc: ở Bắc Mỹ', 150000, 120000, 'hoahuongduong.jpg', 'Bó', 1, '2016-10-26 03:00:16', '2016-10-24 22:11:00'),
(4, 'Hoa mai châu', 5, 'Còn gọi nôm na là mai “trâu” vì hoa to và rất phổ biến, mọc khắp nơi ở miền Nam, có nơi mọc thành rừng, cả núi như Mai Lĩnh, nhưng không sai hoa bằng mai sẻ. Loại mai này có hoa 5 cánh màu vàng tươi rất đẹp, rất được ưa chuộng để chưng trong dịp Tết nguyên đán.', 160000, 0, 'hoamaichau.jpg', 'Bó', 1, '2016-10-26 03:00:16', '2016-10-24 22:11:00'),
(11, 'True Lavender', 3, 'Hoa True Lavender khô nếu biết cách bảo quản tốt sẽ giữ được màu sắc, mùi thơm rất lâu, trung bình từ 3 – 5 năm. True Lavender khó trồng, lượng hoa thu hoạch được ít nên hoa khô và tinh dầu lavender nguyên chất có giá thành cao hơn so với các loại Lavender khác.', 250000, 0, 'truelavender.jpg', 'Bó', 0, '2016-10-12 02:00:00', '2016-10-27 02:24:00'),
(18, 'Lan hồ điệp (Phalaenosis)', 2, 'Có thể nói rằng, lan hồ điệp là một trong những loài lan phổ biến nhất hiện nay với dáng cây đẹp, hoa to, màu sắc sặc sỡ và độc đáo, nở vào cuối mùa đông sang mùa xuân năm sau. Hoa không chỉ được trồng trang trí ban công, vườn nhà, loại hoa này còn trở thành món quà độc đáo và ý nghĩa người ta vẫn thường lựa chọn để biếu tặng nhau trong dịp lễ tết.', 180000, 0, 'lanhodiep.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(19, 'Lan vũ nữ (Oncidium)', 2, 'Sở dĩ loại hoa này có cái tên mỹ miều đến vậy bởi những cánh hoa đầy màu sắc mỏng manh, uốn lượn như những vũ công, cuốn hút bất kỳ ánh nhìn nào. Loài hoa này thuộc giống lan đa thân, cũng rất đa dạng với nhiều màu sắc khác nhau với 26 màu hoa, có loại không mang mùi hương, có loại cho mùi hương đặc biệt như vũ nữ socola.', 150000, 0, 'lanvunu.jpg', 'Bó', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(20, 'Lan Cattleya', 2, 'Lan Cattleya – nữ hoàng của các loài lan, có nguồn gốc từ Mexico và Tây Ấn, đã được phát hiện và trồng từ rất lâu và là loại lan khá phổ biến với người chơi lan Việt Nam. Hoa nở thành các màu như đỏ, hồng, trắng, vàng và cam hai lần một năm và kéo dài trong tuần, có thể nở lại nhanh chóng và rực rỡ nhất khi có đủ điều kiện ánh sáng.', 150000, 0, 'lancattleya.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(21, 'Lan Vanda', 2, 'Thuộc nhóm cây đơn thân, Vanda có hoa mọc giữa thân, đây là loại lan đòi hỏi ánh sáng và độ ẩm cao nên tần suất ra hoa trong một năm cũng không hề nhiều. Vanda có khoảng 50 loại khác nhau với màu sắc rất độc đáo, nổi bật.', 160000, 150000, 'lanvanda.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(22, 'Hồng Eden', 1, 'Hoa hồng leo Eden là một giống hoa hồng nhập ngoại thuộc dòng hồng cổ Anh, cây có nhiều đặc tính vượt trội như: cây khỏe, khả năng leo dàn tốt, có thể leo đến cao hơn 2m. Khả năng kháng sâu bệnh rất tốt, hoa mang màu đỏ nhung rất cuốn hút người nhìn, độ dày cánh khá dày, kích thước hoa có đường kính trung bình có thể lên tới 11 - 12 cm.', 160000, 150000, 'hong_eden.jpg', 'Bó', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(23, 'Hoa hồng leo Madame Alfred Carriere', 1, 'Hoa hồng leo Mdame Alfred Carriere có sức sống mạnh, cây trưởng thành ra hoa quanh năm, chống chịu thời tiết khắc nghiệt. Chúng được trồng nhiều tại các khu biệt thự ở France, trong các lối đi ra vườn, hành lang hai bên, tạo hương thơm lan tỏa rất dễ chịu. ', 180000, 0, 'hong_mdame.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(24, 'Hồng New Dawn', 1, 'Là loại hồng leo rất phổ biến trong những khu vườn với sự khỏe mạnh và lan tràn rộng. Với mùi thơm nhẹ nhàng, bắt đầu bằng một màu hồng mờ dần đến gần như trắng ở cuối chu kỳ nở để lộ nhị hoa màu vàng nổi bật. Là loại hồng leo hiện đại với khoảng 35 cánh hoa, New Dawn luôn được lựa chọn bởi sự lặp lại nhanh và mạnh mẽ, từng cụm từng cụm. Có thể đạt chiều cao tới 6,5m, New Dawn thích hợp cho việc phủ kín hàng rào hay những mảng tường dài ngôi nhà bạn. Lan man theo chiều ngang sẽ giúp cho cây sản xuất nhiều cành nhánh và nhiều hoa hơn.', 180000, 0, 'hong_newdawn.jpg', 'Bó', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(25, 'Hồng Renae', 1, 'Là loại hoa nở thành từng chùm, màu hồng thơm nhẹ, sức sống mãnh liệt. Có khả năng leo giàn, bờ tường cũng như trồng trong chậu. Hồng leo Renae thích hợp trồng ở bờ tường nhà, sân thượng, hàng rào. ', 80000, 70000, 'hong_renae.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(26, 'Hồng Zephirine Drouhin', 1, 'Zephirine Drouhin là một trong những giống hồng leo nổi tiếng của Pháp với mùi thơm tuyệt vời, mạnh mẽ và bền bỉ. Hoa hồng nở rộ và hầu như liên tục. Tuy nhiên khả năng chống chịu bệnh của nó khá kém, không thích hợp với những người chưa có nhiều kinh nghiệm chăm sóc hồng ngoại. Tuy nhiên tại Việt Nam, giống hồng này cũng chưa phổ biến nhiều.', 50000, 0, 'hong_zephirine_drouhin.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(30, 'Spike Lavender', 3, 'Spike Lavender có lượng tinh dầu gấp 3 lần so với True lavender, nhưng mùi hương không đặc sắc bằng. Tinh dầu Spike Lavender thường sử dụng trong các sản phẩm xịt thơm phòng, chất khử mùi, sữa tắm, xà phòng… và nhiều ứng dụng khác.', 380000, 350000, 'spikelavender.jpg', 'Bó', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(32, ' Hoa cúc Anh', 4, 'Cúc Anh là loại cúc có nguồn gốc từ Châu Âu, khu vực Bắc Phi và Địa Trung Hải. Loại hoa có chiều cao thấp thường từ 14 – 17 cm nhưng hoa nở cực đẹp lung linh nên được rất nhiều người mua hạt giống hoa cúc anh về trồng và chăm sóc ngay tại nhà trong các chậu hoa.', 380000, 350000, 'hoacucanh.jpg', 'Bó', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(33, 'Cúc chi trắng', 4, 'Cúc chi trắng có lẽ là loại hoa quen thuộc nhất trong đời sống của người Việt Nam, loài cúc có vẻ đẹp bình dị, không qua sắc sỡ nhưng cũng làm cho người ngắm mê hồn. Bên cạnh đó hoa cúc còn được ứng dụng trong đời sống của con người rất nhiều vừa làm vật trang trí, làm trà uống và có thể chữa được một số bệnh thường gặp.', 280000, 250000, 'cucchitrang.jpg', 'Bó', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(51, 'Bánh su kem sữa tươi chiên giòn', 7, '', 150000, 0, '1434429117-banh-su-kem-chien-20.jpg', 'hộp', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(52, 'Bánh su kem dâu sữa tươi', 7, '', 150000, 0, 'sukemdau.jpg', 'hộp', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(53, 'Bánh su kem bơ sữa tươi', 7, '', 150000, 0, 'He-Thong-Banh-Su-Singapore-Chewy-Junior.jpg', 'hộp', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(54, 'Bánh su kem nhân trái cây sữa tươi', 7, '', 150000, 0, 'foody-banh-su-que-635930347896369908.jpg', 'hộp', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(55, 'Bánh su kem cà phê', 7, '', 150000, 0, 'banh-su-kem-ca-phe-1.jpg', 'hộp', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(56, 'Bánh su kem phô mai', 7, '', 150000, 0, '50020041-combo-20-banh-su-que-pho-mai-9.jpg', 'hộp', 0, '2016-10-13 02:20:00', '2016-10-19 03:20:00'),
(57, 'Bánh su kem sữa tươi chocolate', 7, '', 150000, 0, 'combo-20-banh-su-que-kem-sua-tuoi-phu-socola.jpg', 'hộp', 1, '2016-10-13 02:20:00', '2016-10-19 03:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `link` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `link`, `image`) VALUES
(1, '', 'banner-01.jpg'),
(2, '', 'banner-02.jpg'),
(3, '', 'banner-03.jpg'),
(4, '', 'banner-04.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `type_products`
--

CREATE TABLE `type_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `type_products`
--

INSERT INTO `type_products` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Hoa Hồng', 'Mỗi loại hoa hồng mang những ý nghĩa khác nhau: hồng nhung biểu tượng cho tình yêu, hồng trắng tôn vinh tình yêu trong sắng, hồng vàng mang lại sự ấm áp,…nhưng đa phần loài hoa này đều thể hiện tình cảm đẹp nhất giữa con người.', 'banh-man-thu-vi-nhat-1.jpg', NULL, NULL),
(2, 'Hoa Lan', 'Từ xa xưa, phong lan được biết đến tượng trưng cho tình yêu, sắc đẹp, sự thanh khiết, quyến rũ, khi thì đại diện cho sự hùng mạnh, dũng cảm, lúc lại là biểu tượng cho sự giàu sang và tinh tế,… Mỗi màu sắc mang ý nghĩa khác nhau nhưng đều vô cùng sâu sắc.', '20131108144733.jpg', '2016-10-12 02:16:15', '2016-10-13 01:38:35'),
(3, 'Hoa Lavender', 'Lavender vốn nổi tiếng ở miền nam nước Pháp như Provence, Avignon. Thực ra oải hương vốn có nguồn gốc từ miền Địa Trung Hải và được biết đến cách đây hàng nghìn năm từ thời Hy Lạp cổ đại. Người La Mã đã gieo trồng nó ở khắp các nước châu Âu, trong đó miền Nam nước Pháp là một trong những nơi có nhiều oải hương nhất.', 'banhtraicay.jpg', '2016-10-18 00:33:33', '2016-10-15 07:25:27'),
(4, 'Hoa Cúc', 'Nhắc tới hoa cúc, người ta nghĩ ngay tới sự trường tồn, lòng cao thượng, đôi khi thể hiện lòng kính mến, niềm vui, khi lại bày tỏ sự lưu luyến khi phải chia tay, gửi gắm nỗi buồn. Theo phong thủy, hoa cúc còn mang đến cho gia đình tài lộc cũng như sự hoan hỉ trong năm mới, giúp ổn định phúc khí trong nhà. ', 'banhkem.jpg', '2016-10-26 03:29:19', '2016-10-26 02:22:22'),
(5, 'Hoa Mai', 'Từ xưa, hoa mai đã được chọn là biểu tượng cho sức sống của mùa xuân, những lộc non mơn mởn cánh hoa vàng rung rinh biểu tượng cho sự may mắn. Người cao tuổi chuộng cái già nua của lão mai, mong muốn tuổi già khỏe mạnh, trường thọ. Còn vóc dáng của hoa thì được ví như người con gái quyền quý, khuê các.', 'crepe.jpg', '2016-10-28 04:00:00', '2016-10-27 04:00:23'),
(6, 'Hoa Sen', 'Hoa sen mang nhiều ý nghĩa vô cùng đặc biệt, là biểu tượng cho sự trong sáng, vẻ đẹp tinh khiết của người phụ nữ Việt và cũng được chọn là quốc hoa của nước ta.', 'pizza.jpg', '2016-10-25 17:19:00', NULL),
(7, 'Hoa hướng dương', 'Hoa tượng trưng cho sự trường thọ và sự trung quân, hiếu nghĩa của quân thần dành cho bậc đế vương, vì luôn luôn chỉ hướng về phía mặt trời. Còn theo văn hóa của người châu Âu, hoa hướng dương lại đại diện cho sự kiên định và niềm tin vào tương lai.', 'sukemdau.jpg', '2016-10-25 17:19:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `phone`, `address`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, 'Hiếu Hiếu', 'hieuhieu06.php@gmail.com', '123', '23456789', 'Hoàng Diệu 2', NULL, '2017-03-23 07:17:33', '2017-03-23 07:17:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bills_ibfk_1` (`id_customer`);

--
-- Indexes for table `bill_detail`
--
ALTER TABLE `bill_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bill_detail_ibfk_2` (`id_product`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_id_type_foreign` (`id_type`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type_products`
--
ALTER TABLE `type_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `bill_detail`
--
ALTER TABLE `bill_detail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `type_products`
--
ALTER TABLE `type_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_id_type_foreign` FOREIGN KEY (`id_type`) REFERENCES `type_products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
